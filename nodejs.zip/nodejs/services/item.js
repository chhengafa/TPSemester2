const Items = require("../models/items")

const findById = async (id) => {
  try {
    const item = await Items.findById(id);
    return item;
  } catch (err) {
    throw "Not found"
  }
}

const findAll = async ()=>{
  // to do
  return await Items.find();
}

const create = async (newItem) => {
  // to do
  const createItem = await Items.create(newItem);
  return createItem;
}

const update = async () => {
  // to do
}

const remove = async () => {
  // to doF
}

module.exports = {
  findById,
  update,
  remove,
  findAll,
  create
}