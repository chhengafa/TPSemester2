const Products = require("../models/products")

const findById = async (id) => {
  try {
    const pro = await Products.findById(id);
    return pro;
  } catch (err) {
    console.log("not found");
  }
}

const findAll = async ()=>{
  // to do
  return await Products.find();
}

const create = async (newPro) => {
  // to do
  const createPro = await Products.create(newPro);
  return createPro;
}

const update = async () => {
  // to do
}

const remove = async () => {
  // to doF
}

module.exports = {
  findById,
  update,
  remove,
  findAll,
  create
}