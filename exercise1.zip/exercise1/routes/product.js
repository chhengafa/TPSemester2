var express = require('express');
const joiValidation = require('../middlewares/joiValidation');
const auth = require('../middlewares/auth');
const { } = require('../schemas');
var router = express.Router();
const productService = require('../services/product');

router.get('/id/:id', auth.ensureSignedIn, async function (req, res, next) {
  const { id } = req.params;
  const result = await productService.findById(id);
  res.json(result);
})

router.post('/create', auth.ensureSignedIn, async (req, res, next) => {
  const {title, price, category, item, user, desc, imageUrl}=req.body;
  const result = await productService.create({title, price, category, item, user, desc, imageUrl});
  res.json({result});
})

// all users
router.get('/all', auth.ensureSignedIn, async(req, res) => {
  // to do
  const result = await productService.findAll();
  return res.json({result});
})

router.post('/update/:id', auth.ensureSignedIn, async (req, res, next) => {
  // to do
  const {id}=req.params;
  console.log(id);
  const {title, price, category, item, user, desc, imageUrl}=req.body;
  const result = await productService.update(id,title, price, category, item, user, desc, imageUrl);
  return res.json({result});
})

router.post('/delete/:id', auth.ensureSignedIn, async (req, res, next) => {
  // to do
  const { id } = req.params;
  const result = await productService.remove(id);
  res.json(result);
})

module.exports = router