var express = require('express');
const joiValidation = require('../middlewares/joiValidation');
const auth = require('../middlewares/auth');
const { } = require('../schemas');
var router = express.Router();
const priceService = require('../services/price');

router.get('/id/:id', auth.ensureSignedIn, async function (req, res, next) {
  const { id } = req.params;
  const result = await priceService.findById(id);
  res.json(result);
})

router.post('/create', auth.ensureSignedIn, async (req, res, next) => {
  const {shop, price, product, desc, imageUrl}=req.body;
  const result = await priceService.create({shop, price, product, desc, imageUrl});
  res.json({result});
})

// all users
router.get('/all', auth.ensureSignedIn, async(req, res) => {
  // to do
  const result = await priceService.findAll();
  return res.json({result});
})

router.post('/update/:id', auth.ensureSignedIn, async (req, res, next) => {
  // to do
  const {id}=req.params;
  console.log(id);
  const {shop, price, product, desc, imageUrl}=req.body;
  const result = await priceService.update(id,shop, price, product, desc, imageUrl);
  return res.json({result});
})

router.post('/delete/:id', auth.ensureSignedIn, async (req, res, next) => {
  // to do
  const { id } = req.params;
  const result = await priceService.remove(id);
  res.json(result);
})

module.exports = router