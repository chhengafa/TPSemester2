const Products = require("../models/products")

const findById = async (id) => {
  try {
    const pro = await Products.findById(id);
    return pro;
  } catch (err) {
    console.log("not found");
  }
}

const findAll = async ()=>{
  // to do
  return await Products.find();
}

const create = async (newPro) => {
  // to do
  const createPro = await Products.create(newPro);
  return createPro;
}

const update = async (id,title, price, category, item, user, desc, imageUrl) => {
  // to do
  const result = await Products.updateOne({_id: id},{title:title,
                                                     price:price,
                                                     category:category,
                                                     item:item,
                                                     user:user,
                                                     desc:desc,
                                                     imageUrl:imageUrl});
  return result;
}

const remove = async (id) => {
  // to do
  const remove= await Products.remove({_id:id});
  return remove;
}

module.exports = {
  findById,
  update,
  remove,
  findAll,
  create
}