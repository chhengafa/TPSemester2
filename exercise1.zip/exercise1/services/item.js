const Items = require("../models/items")

const findById = async (id) => {
  try {
    const item = await Items.findById(id);
    return item;
  } catch (err) {
    throw "Not found"
  }
}

const findAll = async ()=>{
  // to do
  return await Items.find();
}

const findItems = async()=>{
  return await Items.aggregate([
    {
      $lookup:{
        from: "product",
        localField:"_id",
        foreignField:"item",
        as:"product"
      }
    }
  ])
}

const create = async (newItem) => {
  // to do
  const createItem = await Items.create(newItem);
  return createItem;
}

const update = async (id,name,category,desc) => {
  // to do
  const result = await Items.updateOne({_id: id},{name:name,category:category,desc:desc});
  return result;
}

const remove = async (id) => {
  // to do
  const remove= await Items.remove({_id:id});
  return remove;
}

module.exports = {
  findById,
  update,
  remove,
  findAll,
  create,
  findItems
}