const Price = require("../models/price")

const findById = async (id) => {
  try {
    const price = await Price.findById(id);
    return price;
  } catch (err) {
    console.log("not found");
  }
}

const findAll = async ()=>{
  // to do
  return await Price.find();
}

const create = async (newPrice) => {
  // to do
  const createprice = await Price.create(newPrice);
  return createprice;
}

const update = async (id,shop, price, product, desc, imageUrl) => {
  // to do
  const result = await Price.updateOne({_id: id},{
                                                     price:price,
                                                     shop:shop,
                                                     product:product,
                                                     desc:desc,
                                                     imageUrl:imageUrl});
  return result;
}

const remove = async (id) => {
  // to do
  const remove= await Price.remove({_id:id});
  return remove;
}

module.exports = {
  findById,
  update,
  remove,
  findAll,
  create
}