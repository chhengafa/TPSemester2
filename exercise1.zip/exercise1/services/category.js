const Categories = require("../models/categories")

const findById = async (id) => {
  // to do
  try {
    const category = await Categories.findById(id);
    return category;
  } catch (err) {
    console.log("not found");
  }
}

const findCategorizedItems = async()=>{
  return await Categories.aggregate([
    {
      $lookup:{
        from: "items",
        localField:"_id",
        foreignField:"category",
        as:"items"
      }
    }
  ])
}

const findAll = async () => {
  // to do
  return await Categories.find();
  
}

const create = async (newCategory) => {
  // to do
  const createCate = await Categories.create(newCategory);
  return createCate;
}

const update = async(id,name, desc,imageUrl) => {
  // to do
  const result = await Categories.updateOne({_id: id},{name:name,desc:desc,imageUrl:imageUrl});
  return result;
}

const remove = async (id) => {
  // to do
  const remove= await Categories.remove({_id:id});
  return remove;
}

module.exports = {
  findById,
  update,
  remove,
  findAll,
  findCategorizedItems,
  create
}