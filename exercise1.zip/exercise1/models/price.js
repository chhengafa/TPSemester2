"use strict"
var mongoose = require('mongoose');
const Schema = mongoose.Schema;

var priceSchema = new mongoose.Schema({
  shop: String,
  price: Number,
  product: {
    type: Schema.Types.ObjectId,
    ref: 'Products'
  },
  imageUrl: String,
  desc: String,
}, {
  timestamps: true,
});

priceSchema.index({ title: 'text' });
var Posts = mongoose.model('Price', priceSchema);
module.exports = Posts;
